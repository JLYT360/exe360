
import express from 'express'
import cors from 'cors'
import helmet from 'helmet'

const app = express()
const PORT = process.env.PORT || 8787
const origins = (process.env.CORS_ORIGINS || '').split(',').filter(Boolean)

app.use(helmet())
app.use(express.json())
app.use(cors({ origin: origins.length ? origins : true }))

app.get('/health', (_req, res) => res.json({ ok: true }))

app.post('/contact', (req, res) => {
  // TODO: Brancher un service mail (EmailJS, Sendgrid...) ou stocker ailleurs
  console.log('Contact payload', req.body)
  res.json({ ok: true })
})

app.listen(PORT, () => console.log(`API on :${PORT}`))
