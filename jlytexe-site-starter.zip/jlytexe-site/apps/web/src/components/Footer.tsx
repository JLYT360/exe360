
import React from 'react'
export default function Footer(){
  return (
    <footer>
      <div className="container">
        <small>© {new Date().getFullYear()} JLYTEXE — Martinique. Pré‑comptabilité = assistance (saisie/préparation), comptes annuels par expert‑comptable.</small>
      </div>
    </footer>
  )
}
