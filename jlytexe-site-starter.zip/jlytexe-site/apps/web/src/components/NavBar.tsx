
import React from 'react'

export default function NavBar(){
  return (
    <header>
      <div className="container" style={{display:'flex',alignItems:'center',justifyContent:'space-between'}}>
        <a href="/" style={{fontWeight:700}}>JLYTEXE</a>
        <nav style={{display:'flex', gap:16}}>
          <a href="/services">Services</a>
          <a href="/tarifs">Tarifs</a>
          <a href="/contact" className="btn">Diagnostic express</a>
        </nav>
      </div>
    </header>
  )
}
