
import React from 'react'
import { createRoot } from 'react-dom/client'
import { createBrowserRouter, RouterProvider } from 'react-router-dom'
import Home from './pages/Home'
import Services from './pages/Services'
import Pricing from './pages/Pricing'
import Contact from './pages/Contact'
import './styles.css'

const router = createBrowserRouter([
  { path: '/', element: <Home /> },
  { path: '/services', element: <Services /> },
  { path: '/tarifs', element: <Pricing /> },
  { path: '/contact', element: <Contact /> },
])

const root = createRoot(document.getElementById('root')!)
root.render(<RouterProvider router={router} />)
