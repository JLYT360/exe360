
import React, { useState } from 'react'
import NavBar from '@/components/NavBar'
import Footer from '@/components/Footer'

export default function Contact(){
  const [sent, setSent] = useState(false)
  return (
    <>
      <NavBar />
      <main className="container">
        <h1>Contact</h1>
        {!sent ? (
          <form onSubmit={(e)=>{e.preventDefault(); setSent(true)}} style={{display:'grid', gap:12, maxWidth:520}}>
            <input required placeholder="Nom" />
            <input required type="email" placeholder="Email" />
            <textarea required placeholder="Votre besoin"></textarea>
            <button className="btn" type="submit">Envoyer</button>
          </form>
        ) : (
          <p>Merci ! Je reviens vers vous rapidement.</p>
        )}
      </main>
      <Footer />
    </>
  )
}
