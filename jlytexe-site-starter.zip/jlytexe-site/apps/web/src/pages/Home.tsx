
import React from 'react'
import NavBar from '@/components/NavBar'
import Footer from '@/components/Footer'

export default function Home(){
  return (
    <>
      <NavBar />
      <main className="container">
        <section className="hero">
          <h1>Structurer, piloter, développer.</h1>
          <p>Assistance administrative · Pré‑comptabilité · Marketing stratégique · Support & Formation — en Martinique.</p>
          <div style={{display:'flex', gap:12, marginTop:16}}>
            <a className="btn" href="/contact">Demander un diagnostic express</a>
            <a href="/tarifs">Voir les offres</a>
          </div>
        </section>
        <section className="grid">
          <div className="card"><h3>Marketing stratégique</h3><p>Plans marketing & communication, lancement, croissance, pilotage.</p></div>
          <div className="card"><h3>Assistance administrative</h3><p>Organisation, relances, modèles, suivi efficace.</p></div>
          <div className="card"><h3>Pré‑comptabilité</h3><p>Saisie & préparation pour l’expert‑comptable, tableaux de bord.</p></div>
          <div className="card"><h3>Support & Formation</h3><p>Dépannage, cloud, sécurité basique, Word/Excel/Drive.</p></div>
        </section>
      </main>
      <Footer />
    </>
  )
}
