
import React from 'react'
import NavBar from '@/components/NavBar'
import Footer from '@/components/Footer'

export default function Pricing(){
  return (
    <>
      <NavBar />
      <main className="container">
        <h1>Tarifs & Packs</h1>
        <p>Forfaits d’heures, abonnements mensuels/annuels et projets ponctuels. Ajustables selon besoins.</p>
        <h2>Forfaits d’heures</h2>
        <pre>
Assistance administrative : 5h 120 €, 10h 220 €, Mensuel (20h) 420 €, Annuel 4 500 €
Pré‑comptabilité : 5h 140 €, 10h 260 €, Mensuel (20h) 500 €, Annuel 5 400 €
Marketing stratégique : 5h 200 €, 10h 380 €, Mensuel (10h) 350 €, Annuel 3 800 €
Support & formation : 5h 150 €, 10h 280 €, Mensuel (10h) 260 €, Annuel 2 880 €
        </pre>
        <h2>Projets ponctuels</h2>
        <pre>
Plan marketing complet : 450–650 €
Plan de communication : 350–550 €
Stratégie de lancement : 400–700 €
        </pre>
        <h2>Taux horaires</h2>
        <pre>
Admin 30 €/h · Pré‑compta 35 €/h · Support/Formation 35 €/h · Stratégie 45 €/h
        </pre>
      </main>
      <Footer />
    </>
  )
}
