
import React from 'react'
import NavBar from '@/components/NavBar'
import Footer from '@/components/Footer'

export default function Services(){
  return (
    <>
      <NavBar />
      <main className="container">
        <h1>Services</h1>
        <h2>Marketing stratégique</h2>
        <ul>
          <li>Plans marketing & communication (analyse, positionnement, feuille de route)</li>
          <li>Lancement d’activité / offre</li>
          <li>Stratégies de croissance (90 jours)</li>
        </ul>
        <h2>Assistance administrative</h2>
        <ul>
          <li>Organisation documentaire, numérisation, relances</li>
          <li>Modèles (devis, factures, procédures)</li>
        </ul>
        <h2>Pré‑comptabilité (assistance)</h2>
        <ul>
          <li>Saisie de pièces, préparation pour votre expert‑comptable</li>
          <li>Suivi factures/dépenses, tableaux de bord</li>
        </ul>
        <h2>Support informatique & Formation</h2>
        <ul>
          <li>Dépannage/installation, organisation cloud</li>
          <li>Formations Word, Excel, Drive</li>
        </ul>
      </main>
      <Footer />
    </>
  )
}
